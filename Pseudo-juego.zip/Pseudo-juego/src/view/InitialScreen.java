package view;

public class InitialScreen {

}
